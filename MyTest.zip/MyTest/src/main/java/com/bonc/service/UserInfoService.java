package com.bonc.service;

import com.bonc.domain.UserInfo;  

public interface UserInfoService {  
  
    public UserInfo findByUsername(String username);  
  
} 
