package com.bonc.service;

import java.security.Identity;
import java.util.List;

import javax.persistence.criteria.Join;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bonc.domain.User;
import com.bonc.repository.IUserRepository;


/**
 * 用户Service
 */
@Service
public class UserService {

    private final IUserRepository repository;

    @Autowired
    public UserService(IUserRepository repository) {
        this.repository = repository;
    }

    public Long add(User user) {
        repository.saveAndFlush(user);
        return user.getId();
    }

    public boolean delete(Long id) {
        repository.delete(id);
        return true;
    }

    public boolean edit(User user) {
        repository.saveAndFlush(user);
        return true;
    }

    public Page<User> list(PageRequest page, final String condition) {
        if (StringUtils.hasText(condition)) {
            return repository.findAll((root, query, cb) -> {
                query.distinct(true);
                Join<User, Identity> identitiesJson = root.join("identities");
                Path<String> loginId = root.get("loginId");
                Path<String> userName = root.get("userName");
                Path<String> departmentName = identitiesJson.get("departmentName");
                Path<String> departmentCode = identitiesJson.get("departmentCode");
                Path<String> stationName = identitiesJson.get("stationName");
                Path<String> stationCode = identitiesJson.get("stationCode");
                Path<String> areaName = identitiesJson.get("areaName");
                Path<String> areaCode = identitiesJson.get("areaCode");
                Predicate[] predicates = {
                        cb.like(loginId, getLikePattern(condition)),
                        cb.like(userName, getLikePattern(condition)),
                        cb.like(departmentName, getLikePattern(condition)),
                        cb.like(departmentCode, getLikePattern(condition)),
                        cb.like(stationName, getLikePattern(condition)),
                        cb.like(stationCode, getLikePattern(condition)),
                        cb.like(areaName, getLikePattern(condition)),
                        cb.like(areaCode, getLikePattern(condition))
                };
                return cb.or(predicates);
            }, page);
        } else {
            return repository.findAll(page);
        }
    }

    public User query(Long id) {
        return repository.findOne(id);
    }
    public List<User> queryAll() {
        return repository.findAll();
    }
    public User query(String loginId, String password) {
        return repository.findByLoginIdAndPassword(loginId, password);
    }

    public boolean existsLoginId(String loginId) {
        return repository.existsByLoginId(loginId);
    }

    private String getLikePattern(final String searchTerm) {
        StringBuilder pattern = new StringBuilder("%");
        pattern.append(searchTerm);
        pattern.append("%");
        return pattern.toString();
    }
    
    
}
