package com.bonc.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


/**
 * 用户实体
 */
@ApiModel(value = "User", description = "用户实体")
@Entity(name = "tb_base_user")
public class User {

    @ApiModelProperty(value = "主键(新增时无效)", required = true)
    @Id
    @GeneratedValue
    private Long id;

    @ApiModelProperty(value = "登陆工号", position = 1)
    @Column(unique = true, length = 50)
    private String loginId;

    @ApiModelProperty(value = "密码(获取用户信息时无此字段)", required = true, position = 2)
    @Column(nullable = false, length = 64)
    private String password;

    @ApiModelProperty(value = "用户名", required = true, position = 3)
    @Column(nullable = false, length = 100)
    private String userName;

    @ApiModelProperty(value = "用户性别(男,女)", position = 4)
    @Column(length = 2)
    private String userSex = "男";

    @ApiModelProperty(value = "用户邮箱", position = 5)
    @Column(length = 50)
    private String userEmail = "";

    @ApiModelProperty(value = "电话号码", position = 6)
    @Column(length = 20)
    private String userPhone = "";

    @ApiModelProperty(value = "专业线Id", position = 7, hidden = true)
    @Column(nullable = false, length = 20, insertable = true, updatable = false)
    @JsonIgnore
    private Long teamId;

    @ApiModelProperty(value = "用户地址", position = 8)
    @Column(length = 255)
    private String userAddress = "";

    @ApiModelProperty(value = "预留属性", position = 9)
    @Column(length = 50)
    private String userAttr = "";

    @ApiModelProperty(value = "用户描述", position = 10)
    @Column(length = 1000)
    private String userRemark = "";

    @ApiModelProperty(value = "是否禁用", required = true, position = 11)
    @Column(nullable = false)
    private boolean disable = false;

    @ApiModelProperty(value = "是否可删除", required = true, position = 12)
    @Column(nullable = false)
    private boolean deletable = false;

    


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserSex() {
        return userSex;
    }

    public void setUserSex(String userSex) {
        this.userSex = userSex;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public Long getTeamId() {
        return teamId;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getUserAttr() {
        return userAttr;
    }

    public void setUserAttr(String userAttr) {
        this.userAttr = userAttr;
    }

    public String getUserRemark() {
        return userRemark;
    }

    public void setUserRemark(String userRemark) {
        this.userRemark = userRemark;
    }

    public boolean isDisable() {
        return disable;
    }

    public void setDisable(boolean disable) {
        this.disable = disable;
    }

    public boolean isDeletable() {
        return deletable;
    }

    public void setDeletable(boolean deletable) {
        this.deletable = deletable;
    }

	@Override
	public String toString() {
		return "User [id=" + id + ", loginId=" + loginId + ", password=" + password + ", userName=" + userName
				+ ", userSex=" + userSex + ", userEmail=" + userEmail + ", userPhone=" + userPhone + ", teamId="
				+ teamId + ", userAddress=" + userAddress + ", userAttr=" + userAttr + ", userRemark=" + userRemark
				+ ", disable=" + disable + ", deletable=" + deletable + "]";
	}

   
}
