package com.bonc.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.bonc.domain.User;

/**
 * 用户DAO
 */
@Repository
public interface IUserRepository extends JpaRepository<User, Long>, JpaSpecificationExecutor<User> {
    boolean existsByLoginId(String loginId);
    
    User findByLoginIdAndPassword(String loginId, String password);
}
