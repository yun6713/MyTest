package com.bonc.repository;

import org.springframework.data.repository.CrudRepository;

import com.bonc.domain.Demo;  
  
public interface DemoDao extends CrudRepository<Demo, Long>{  
Demo findByName(String name);  
}  
