package com.bonc.quartz;

import java.util.Date;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class TestScheduler {
	public static void main(String[] args) {
		StdSchedulerFactory ssf = new StdSchedulerFactory();
		try {
			Scheduler sche = ssf.getScheduler();
			JobDetail jd = JobBuilder.newJob(testJob.class)
					.withDescription("1")
					.withIdentity("j", "js")
					.build();
			Trigger t = TriggerBuilder.newTrigger()
					.withDescription("2")
					.withIdentity("k", "ks")
					.startAt(new Date(System.currentTimeMillis()+5000))
					.endAt(new Date(System.currentTimeMillis()+15000))
					.withSchedule(SimpleScheduleBuilder.repeatSecondlyForever())
					.build();
			sche.scheduleJob(jd, t);
			sche.start();
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}
