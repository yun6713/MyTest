package com.bonc.quartz;

import java.sql.Date;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class testJob implements Job{

	public void execute(JobExecutionContext context) throws JobExecutionException {
		System.out.println(new Date(System.currentTimeMillis()));
		
	}

}
