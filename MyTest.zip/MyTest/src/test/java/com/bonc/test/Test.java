package com.bonc.test;

import org.junit.Before;

public class Test {

	
	@Before
	public void getConnection() {
		
	}
	
	
}
